from __future__ import print_function, division

import csv
import functools
import json
import os
import random
import warnings

import numpy as np
import torch
from pymatgen.core.structure import Structure
from torch.utils.data import Dataset, DataLoader
from torch.utils.data.dataloader import default_collate
from torch.utils.data.sampler import SubsetRandomSampler

# modified here
from pymatgen.analysis.local_env import CrystalNN
from collections import defaultdict
from pymatgen.core.periodic_table import Element


def get_train_val_test_loader(dataset, collate_fn=default_collate,
                              batch_size=64, train_ratio=None,
                              val_ratio=0.1, test_ratio=0.1, return_test=False,
                              num_workers=1, pin_memory=False, **kwargs):
    """
    Utility function for dividing a dataset to train, val, test datasets.

    !!! The dataset needs to be shuffled before using the function !!!

    Parameters
    ----------
    dataset: torch.utils.data.Dataset
      The full dataset to be divided.
    collate_fn: torch.utils.data.DataLoader
    batch_size: int
    train_ratio: float
    val_ratio: float
    test_ratio: float
    return_test: bool
      Whether to return the test dataset loader. If False, the last test_size
      data will be hidden.
    num_workers: int
    pin_memory: bool

    Returns
    -------
    train_loader: torch.utils.data.DataLoader
      DataLoader that random samples the training data.
    val_loader: torch.utils.data.DataLoader
      DataLoader that random samples the validation data.
    (test_loader): torch.utils.data.DataLoader
      DataLoader that random samples the test data, returns if
        return_test=True.
    """
    total_size = len(dataset)
    if kwargs['train_size'] is None:
        if train_ratio is None:
            assert val_ratio + test_ratio < 1
            train_ratio = 1 - val_ratio - test_ratio
            print(f'[Warning] train_ratio is None, using 1 - val_ratio - '
                  f'test_ratio = {train_ratio} as training data.')
        else:
            assert train_ratio + val_ratio + test_ratio <= 1
    indices = list(range(total_size))
    if kwargs['train_size']:
        train_size = kwargs['train_size']
    else:
        train_size = int(train_ratio * total_size)
    if kwargs['test_size']:
        test_size = kwargs['test_size']
    else:
        test_size = int(test_ratio * total_size)
    if kwargs['val_size']:
        valid_size = kwargs['val_size']
    else:
        valid_size = int(val_ratio * total_size)
    train_sampler = SubsetRandomSampler(indices[:train_size])
    val_sampler = SubsetRandomSampler(
        indices[-(valid_size + test_size):-test_size])
    if return_test:
        test_sampler = SubsetRandomSampler(indices[-test_size:])
    train_loader = DataLoader(dataset, batch_size=batch_size,
                              sampler=train_sampler,
                              num_workers=num_workers,
                              collate_fn=collate_fn, pin_memory=pin_memory)
    val_loader = DataLoader(dataset, batch_size=batch_size,
                            sampler=val_sampler,
                            num_workers=num_workers,
                            collate_fn=collate_fn, pin_memory=pin_memory)
    if return_test:
        test_loader = DataLoader(dataset, batch_size=batch_size,
                                 sampler=test_sampler,
                                 num_workers=num_workers,
                                 collate_fn=collate_fn, pin_memory=pin_memory)
    if return_test:
        return train_loader, val_loader, test_loader
    else:
        return train_loader, val_loader


def collate_pool(dataset_list):
    """
    Collate a list of data and return a batch for predicting crystal
    properties.

    Parameters
    ----------

    dataset_list: list of tuples for each data point.
      (atom_fea, nbr_fea, nbr_fea_idx, target)

      atom_fea: torch.Tensor shape (n_i, atom_fea_len)
      nbr_fea: torch.Tensor shape (n_i, M, nbr_fea_len)
      nbr_fea_idx: torch.LongTensor shape (n_i, M)
      target: torch.Tensor shape (1, )
      cif_id: str or int

    Returns
    -------
    N = sum(n_i); N0 = sum(i)

    batch_atom_fea: torch.Tensor shape (N, orig_atom_fea_len)
      Atom features from atom type
    batch_nbr_fea: torch.Tensor shape (N, M, nbr_fea_len)
      Bond features of each atom's M neighbors
    batch_nbr_fea_idx: torch.LongTensor shape (N, M)
      Indices of M neighbors of each atom
    crystal_atom_idx: list of torch.LongTensor of length N0
      Mapping from the crystal idx to atom idx
    target: torch.Tensor shape (N, 1)
      Target value for prediction
    batch_cif_ids: list
    """
    batch_atom_fea, batch_nbr_fea, batch_nbr_fea_idx = [], [], []
    crystal_atom_idx, batch_target = [], []
    batch_cif_ids = []
    base_idx = 0
    for i, ((atom_fea, nbr_fea, nbr_fea_idx), target, cif_id)\
            in enumerate(dataset_list):
        n_i = atom_fea.shape[0]  # number of atoms for this crystal
        batch_atom_fea.append(atom_fea)
        batch_nbr_fea.append(nbr_fea)
        batch_nbr_fea_idx.append(nbr_fea_idx+base_idx)
        new_idx = torch.LongTensor(np.arange(n_i)+base_idx)
        crystal_atom_idx.append(new_idx)
        batch_target.append(target)
        batch_cif_ids.append(cif_id)
        base_idx += n_i
    return (torch.cat(batch_atom_fea, dim=0),
            torch.cat(batch_nbr_fea, dim=0),
            torch.cat(batch_nbr_fea_idx, dim=0),
            crystal_atom_idx),\
        torch.stack(batch_target, dim=0),\
        batch_cif_ids


class GaussianDistance(object):
    """
    Expands the distance by Gaussian basis.

    Unit: angstrom
    """
    def __init__(self, dmin, dmax, step, var=None):
        """
        Parameters
        ----------

        dmin: float
          Minimum interatomic distance
        dmax: float
          Maximum interatomic distance
        step: float
          Step size for the Gaussian filter
        """
        assert dmin < dmax
        assert dmax - dmin > step
        self.filter = np.arange(dmin, dmax+step, step)
        if var is None:
            var = step
        self.var = var

    def expand(self, distances):
        """
        Apply Gaussian disntance filter to a numpy distance array

        Parameters
        ----------

        distance: np.array shape n-d array
          A distance matrix of any shape

        Returns
        -------
        expanded_distance: shape (n+1)-d array
          Expanded distance matrix with the last dimension of length
          len(self.filter)
        """
        return np.exp(-(distances[..., np.newaxis] - self.filter)**2 /
                      self.var**2)


class AtomInitializer(object):
    """
    Base class for intializing the vector representation for atoms.

    !!! Use one AtomInitializer per dataset !!!
    """
    def __init__(self, atom_types):
        self.atom_types = set(atom_types)
        self._embedding = {}

    def get_atom_fea(self, atom_type):
        assert atom_type in self.atom_types
        return self._embedding[atom_type]

    def load_state_dict(self, state_dict):
        self._embedding = state_dict
        self.atom_types = set(self._embedding.keys())
        self._decodedict = {idx: atom_type for atom_type, idx in
                            self._embedding.items()}

    def state_dict(self):
        return self._embedding

    def decode(self, idx):
        if not hasattr(self, '_decodedict'):
            self._decodedict = {idx: atom_type for atom_type, idx in
                                self._embedding.items()}
        return self._decodedict[idx]


class AtomCustomJSONInitializer(AtomInitializer):
    """
    Initialize atom feature vectors using a JSON file, which is a python
    dictionary mapping from element number to a list representing the
    feature vector of the element.

    Parameters
    ----------

    elem_embedding_file: str
        The path to the .json file
    """
    def __init__(self, elem_embedding_file):
        with open(elem_embedding_file) as f:
            elem_embedding = json.load(f)
        elem_embedding = {int(key): value for key, value
                          in elem_embedding.items()}
        atom_types = set(elem_embedding.keys())
        super(AtomCustomJSONInitializer, self).__init__(atom_types)
        for key, value in elem_embedding.items():
            self._embedding[key] = np.array(value, dtype=float)


class CIFData(Dataset):
    """
    The CIFData dataset is a wrapper for a dataset where the crystal structures
    are stored in the form of CIF files. The dataset should have the following
    directory structure:

    root_dir
    ├── id_prop.csv
    ├── atom_init.json
    ├── id0.cif
    ├── id1.cif
    ├── ...

    id_prop.csv: a CSV file with two columns. The first column recodes a
    unique ID for each crystal, and the second column recodes the value of
    target property.

    atom_init.json: a JSON file that stores the initialization vector for each
    element.

    ID.cif: a CIF file that recodes the crystal structure, where ID is the
    unique ID for the crystal.

    Parameters
    ----------

    root_dir: str
        The path to the root directory of the dataset
    max_num_nbr: int
        The maximum number of neighbors while constructing the crystal graph
    radius: float
        The cutoff radius for searching neighbors
    dmin: float
        The minimum distance for constructing GaussianDistance
    step: float
        The step size for constructing GaussianDistance
    random_seed: int
        Random seed for shuffling the dataset

    Returns
    -------

    atom_fea: torch.Tensor shape (n_i, atom_fea_len)
    nbr_fea: torch.Tensor shape (n_i, M, nbr_fea_len)
    nbr_fea_idx: torch.LongTensor shape (n_i, M)
    target: torch.Tensor shape (1, )
    cif_id: str or int
    """
    def __init__(self, root_dir, id_prop_csv, atom_init_json, use_unique_atom=False, max_num_nbr=12, radius=8, dmin=0, step=0.2,
                 random_seed=123):
        self.root_dir = root_dir
        self.max_num_nbr, self.radius = max_num_nbr, radius
        assert os.path.exists(root_dir), 'root_dir does not exist!'

        self.use_unique_atom = use_unique_atom
        # id_prop_file = os.path.join(self.root_dir, 'id_prop.csv')
        id_prop_file = id_prop_csv
        assert os.path.exists(id_prop_file), 'id_prop.csv does not exist!'
        with open(id_prop_file) as f:
            reader = csv.reader(f)
            self.id_prop_data = [row for row in reader]
        random.seed(random_seed)
        random.shuffle(self.id_prop_data)
        
        atom_init_file = atom_init_json
        # atom_init_file = os.path.join(self.root_dir, 'atom_init.json')
        assert os.path.exists(atom_init_file), 'atom_init.json does not exist!'
        self.ari = AtomCustomJSONInitializer(atom_init_file)
        self.gdf = GaussianDistance(dmin=dmin, dmax=self.radius, step=step)

    def __len__(self):
        return len(self.id_prop_data)

    @functools.lru_cache(maxsize=None)  # Cache loaded structures
    def __getitem__(self, idx):
        cif_id, target = self.id_prop_data[idx]

        # ===== modified =======
        cif_path = os.path.join(self.root_dir, cif_id+'.cif')
        if self.use_unique_atom:
            unique_atom_indices, unique_atom_weight, crystal = get_unique_atoms_from_cif(cif_path)
            crystal = Structure.from_file(cif_path)
                    
            # Atom features for all atoms
            atom_fea_all = np.vstack([self.ari.get_atom_fea(crystal[i].specie.number)
                                    for i in range(len(crystal))])
            # Neighbor info for all atoms
            all_nbrs = crystal.get_all_neighbors(self.radius, include_index=True)
            all_nbrs = [sorted(nbrs, key=lambda x: x[1]) for nbrs in all_nbrs]
            # nbr_fea_idx, nbr_fea = [], []
            nbr_fea_idx_all, nbr_fea_all = [], []
            for nbr in all_nbrs:
                if len(nbr) < self.max_num_nbr:
                    nbr_fea_idx_all.append(list(map(lambda x: x[2], nbr)) +
                                    [0] * (self.max_num_nbr - len(nbr)))
                    nbr_fea_all.append(list(map(lambda x: x[1], nbr)) +
                                [self.radius + 1.] * (self.max_num_nbr - len(nbr)))
                else:
                    nbr_fea_idx_all.append(list(map(lambda x: x[2], nbr[:self.max_num_nbr])))
                    nbr_fea_all.append(list(map(lambda x: x[1], nbr[:self.max_num_nbr])))
            nbr_fea_idx_all, nbr_fea_all = np.array(nbr_fea_idx_all), np.array(nbr_fea_all)
            nbr_fea_all = self.gdf.expand(nbr_fea_all)

            # Only keep unique atoms
            atom_fea = torch.Tensor(atom_fea_all[unique_atom_indices])
            nbr_fea = torch.Tensor(nbr_fea_all[unique_atom_indices])

            # Remap neighbor indices to new unique atom indices
            orig_to_unique = {orig_idx: new_idx for new_idx, orig_idx in enumerate(unique_atom_indices)}
            remapped_nbr_fea_idx = []
            for orig_idx in unique_atom_indices:
                nbrs = nbr_fea_idx_all[orig_idx]
                remapped = [orig_to_unique[nidx] if nidx in orig_to_unique else 0 for nidx in nbrs]
                remapped_nbr_fea_idx.append(remapped)
            nbr_fea_idx = torch.LongTensor(remapped_nbr_fea_idx)
            target = torch.Tensor([float(target)])
            return (atom_fea, nbr_fea, nbr_fea_idx), target, cif_id
        # ======================
        else:
            crystal = Structure.from_file(cif_path)
            atom_fea = np.vstack([self.ari.get_atom_fea(crystal[i].specie.number)
                                for i in range(len(crystal))])
            atom_fea = torch.Tensor(atom_fea)
            all_nbrs = crystal.get_all_neighbors(self.radius, include_index=True)
            all_nbrs = [sorted(nbrs, key=lambda x: x[1]) for nbrs in all_nbrs]
            nbr_fea_idx, nbr_fea = [], []
            for nbr in all_nbrs:
                if len(nbr) < self.max_num_nbr:
                    warnings.warn('{} not find enough neighbors to build graph. '
                                'If it happens frequently, consider increase '
                                'radius.'.format(cif_id))
                    nbr_fea_idx.append(list(map(lambda x: x[2], nbr)) +
                                    [0] * (self.max_num_nbr - len(nbr)))
                    nbr_fea.append(list(map(lambda x: x[1], nbr)) +
                                [self.radius + 1.] * (self.max_num_nbr -
                                                        len(nbr)))
                else:
                    nbr_fea_idx.append(list(map(lambda x: x[2],
                                                nbr[:self.max_num_nbr])))
                    nbr_fea.append(list(map(lambda x: x[1],
                                            nbr[:self.max_num_nbr])))
            nbr_fea_idx, nbr_fea = np.array(nbr_fea_idx), np.array(nbr_fea)
            nbr_fea = self.gdf.expand(nbr_fea)
            atom_fea = torch.Tensor(atom_fea)
            nbr_fea = torch.Tensor(nbr_fea)
            nbr_fea_idx = torch.LongTensor(nbr_fea_idx)
            target = torch.Tensor([float(target)])
            return (atom_fea, nbr_fea, nbr_fea_idx), target, cif_id


# Modified
def get_unique_atoms_from_cif(cif_path):
    """
    Given a CIF file, determine the unique atoms in the structure based on the vector method described in prompt_uniqueatom.md.
    Returns:
        unique_atom_indices: list of indices of unique atoms
        unique_atom_vectors: list of vectors for unique atoms
        atom_groups: dict mapping vector tuple to list of atom indices
    """
    # Load structure
    structure = Structure.from_file(cif_path)
    atomic_numbers = [site.specie.Z for site in structure.sites]
    n_atoms = len(structure.sites)

    # Get atomic radii from pymatgen
    atomic_radii = {}
    for site in structure.sites:
        element = Element.from_Z(site.specie.Z)
        # Use atomic radius, fallback to covalent radius if atomic radius not available
        try:
            radius = element.atomic_radius
        except:
            radius = element.covalent_radius
        atomic_radii[site.specie.Z] = radius

    # Precompute neighbors up to 3 bonds away using atomic radii
    neighbors_dict = {i: {1: set(), 2: set(), 3: set()} for i in range(n_atoms)}
    
    # 1st shell neighbors using atomic radii with periodic conditions
    for i in range(n_atoms):
        center_atom = structure[i]
        center_radius = atomic_radii[center_atom.specie.Z]
        
        # Get all neighbors within cutoff distance (sum of radii + small buffer)
        # cutoff = center_radius + max(atomic_radii.values()) + 0.5  # 0.5Å buffer
        cutoff = 8
        neighbors = structure.get_neighbors(center_atom, cutoff)
        
        # Filter neighbors based on bond distance (sum of atomic radii)
        for neighbor in neighbors:
            neighbor_idx = neighbor.index
            if neighbor_idx != i:
                neighbor_radius = atomic_radii[structure[neighbor_idx].specie.Z]
                bond_distance = center_radius + neighbor_radius
                
                # If distance is within bond length (with some tolerance)
                if neighbor.distance(center_atom) <= bond_distance * 1.3:  # 30% tolerance
                    neighbors_dict[i][1].add(neighbor_idx)
    
    # 2nd and 3rd shell neighbors
    for i in range(n_atoms):
        n1 = neighbors_dict[i][1]
        n2 = set()
        for j in n1:
            n2.update(neighbors_dict[j][1])
        n2.discard(i)
        n2 -= n1
        neighbors_dict[i][2] = n2
    
    for i in range(n_atoms):
        n2 = neighbors_dict[i][2]
        n3 = set()
        for j in n2:
            n3.update(neighbors_dict[j][1])
        n3.discard(i)
        n3 -= neighbors_dict[i][1]
        n3 -= n2
        neighbors_dict[i][3] = n3

    # Build the vector for each atom
    vectors = []
    for i in range(n_atoms):
        n_i = atomic_numbers[i]
        N1 = [atomic_numbers[j] for j in neighbors_dict[i][1]]
        N2 = [atomic_numbers[j] for j in neighbors_dict[i][2]]
        N3 = [atomic_numbers[j] for j in neighbors_dict[i][3]]
        vec = [
            n_i,
            len(N1),
            # int(sum(N1)),
            int(sum([x**2 for x in N1])),
            len(N2),
            # int(sum(N2)),
            int(sum([x**2 for x in N2])),
            len(N3),   # using length
            # int(sum(N3)),
            int(sum([x**2 for x in N3])),
        ]
        vectors.append(tuple(vec))

    # Group atoms by their vectors
    vector_to_indices = defaultdict(list)
    for idx, vec in enumerate(vectors):
        vector_to_indices[vec].append(idx)

    unique_atom_vectors = list(vector_to_indices.keys())
    unique_atom_indices = [indices[0] for indices in vector_to_indices.values()]
    # atom_groups = dict(vector_to_indices)
    unique_atom_weight = [len(indices) for indices in vector_to_indices.values()]

    return unique_atom_indices, unique_atom_weight, structure